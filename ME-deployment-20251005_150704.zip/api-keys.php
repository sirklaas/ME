<?php
/**
 * API Configuration for Masked Employee Project
 * 
 * SECURITY WARNING:
 * - This file contains sensitive API keys
 * - Do NOT commit this to git
 * - Add to .gitignore immediately
 * - Keep permissions restricted (chmod 600)
 */

// Prevent direct access
if (!defined('MASKED_EMPLOYEE_APP')) {
    die('Direct access not permitted');
}

// Freepik API Configuration
define('FREEPIK_API_KEY', 'FPSX6db86501e35162e1c0fb6412911dd49a');
define('FREEPIK_API_URL', 'https://api.freepik.com/v1/ai/text-to-image');

// OpenAI API Configuration
define('OPENAI_API_KEY', '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');
define('OPENAI_API_URL', 'https://api.openai.com/v1/chat/completions');
define('OPENAI_MODEL', 'gpt-4o'); // Latest model (or use 'gpt-4-turbo', 'gpt-4', 'gpt-3.5-turbo')

// PocketBase Configuration
define('POCKETBASE_URL', 'https://pinkmilk.pockethost.io');
define('POCKETBASE_ADMIN_TOKEN', 'biknu8-pyrnaB-mytvyx');
define('POCKETBASE_COLLECTION', 'submissions');

// Image Storage Configuration
define('IMAGE_STORAGE_PATH', __DIR__ . '/generated-images/');
define('IMAGE_PUBLIC_URL', 'https://www.pinkmilk.eu/ME/generated-images/');

// Email Configuration (Optional)
define('SMTP_ENABLED', false); // Set to true when ready
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', ''); // Your email
define('SMTP_PASS', ''); // App-specific password
define('SMTP_FROM_EMAIL', 'noreply@pinkmilk.eu');
define('SMTP_FROM_NAME', 'The Masked Employee');

// Application Settings
define('ENABLE_AI_GENERATION', true);
define('DEBUG_MODE', true); // Set to false in production
define('LOG_API_CALLS', true);
define('MAX_RETRIES', 3); // API retry attempts

// Freepik Image Generation Settings
define('FREEPIK_IMAGE_SIZE', '1024x1024');
define('FREEPIK_STYLE', 'realistic'); // Options: realistic, digital-art, illustration
define('FREEPIK_AI_MODEL', 'flux-1'); // Options: flux-1, sdxl, freepik-default
define('FREEPIK_NUM_INFERENCE_STEPS', 50); // 25-100 (higher = better quality)
define('FREEPIK_GUIDANCE_SCALE', 7.5); // 5-15 (how closely to follow prompt)

// Character Generation Settings
define('GENERATE_CHARACTER_IMAGE', true);
define('GENERATE_ENVIRONMENT_IMAGE', true);
define('IMAGES_PER_PERSON', 2); // Character + Environment

// Log file paths
define('LOG_DIR', __DIR__ . '/logs/');
define('ERROR_LOG', LOG_DIR . 'errors.log');
define('API_LOG', LOG_DIR . 'api-calls.log');
define('GENERATION_LOG', LOG_DIR . 'generation.log');

?>
